<footer id="footer">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong|">
	<style>
		h4.a{
			  font-family: "Sofia", sans-serif;
  font-size: 30px;
  text-shadow: 3px 3px 3px #ababab;
		}
	  h6.d{
			font-family: "Trirong", sans-serif;
			text-shadow: 3px 3px 3px #ababab;
		}
		p.b{
			  font-family: "Sofia", sans-serif;
  font-size: 30px;
  text-shadow: 3px 3px 3px #ababab;
		}
		p.c{
			text-shadow:  0px 1px 1px #aaa;
		}
		 p.d{
			font-family:  "Audiowide", sans-serif;
			text-shadow: 3px 3px 3px #bbb;
		}
			 .binil {
        background-color: #1c87c9;
        -webkit-border-radius: 60px;
        border-radius: 60px;
        border: none;
        color: #eeeeee;
        cursor: pointer;
        display: inline-block;
        font-family: sans-serif;
        font-size: 20px;
        padding: 5px 15px;
        text-align: center;
        text-decoration: none;
      }
      @keyframes glowing {
        0% {
          background-color: #2ba805;
          box-shadow: 0 0 5px #2ba805;
        }
        50% {
          background-color: #49e819;
          box-shadow: 0 0 20px #49e819;
        }
        100% {
          background-color: #2ba805;
          box-shadow: 0 0 5px #2ba805;
        }
      }
      .binil {
        animation: glowing 1300ms infinite;
      }
		
	</style>
			
			<div class="section">
				
				<div class="container">
					
					<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">About Us</h3>

								<h2 class="a">&nbsp;Dress World</h2>
								<p class="b"><sup>&nbsp;--House Of Wears--<sup></p>
								<p class="c"><b>Quality and Affordability is our Hallmark!<br>
								Dress World Clothing never settles for less when it comes
								to its designs and product quality.All products are built to last so they can carry out their purpose of sending out motivational messages to people 
							  that need them the most.</b></p>
							  <h6 class="d">Trendy Motivation</h6>
							  	<p class="d">Get yourself a Dress World Branded item, you will surely be glad you did.<br></p>
							  	    <a class="binil" href="#">ORDER NOW</a>
                      



								
								<ul class="footer-links">
									<li><a href="#"><br><i class="fa fa-map-marker"></i>Dress World, Kottayam</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>1800 444 001</a></li>
									<li><a href="#"><i class="fa fa-envelope-o"></i>DressWorld.com</a></li>
								</ul>
							</div>
						</div>
						<div class="col-md-6 text-center" style="margin-top:80px;">
							<ul class="footer-payments">
								<li><a href="#"><i class="fa fa-cc-visa" style="color:navy;"></i></a></li>
								<li><a href="#"><i class="fa fa-credit-card" style="color:blue;"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-paypal" style="color:red;"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-mastercard" style="color:yellow;"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-discover" style="color: aqua;"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-amex" style="color: orange;"></i></a></li>
							</ul>
							<span class="copyright">
								
								Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This Dress World Store is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#" target="_blank">Binil,Felbin,Asish</a>
							
							</span>


						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Categories</h3>
								<ul class="footer-links">
									<li><a href="#"><u><b>MENS WEAR</b></u></a></li>
									<li><a href="#">-<b>&nbsp;Shirt</b></a></li>
									<li><a href="#">-<b>&nbsp;T-shirt</b></a></li>
									<li><a href="#">-<b>&nbsp;Kurtas</b></a></li>
									<li><a href="#">-<b>&nbsp;Trousers</b></a></li>
									<li><a href="#">-<b>&nbsp;Jeans</b></a></li>
									<li><a href="#">-<b>&nbsp;Hoodies</b></a></li>
									<li><a href="#">-<b>&nbsp;Jackets</b></a></li>
									<li><a href="#">-<b>&nbsp;Shorts</b></a></li>
									<li><a href="#">-<b>&nbsp;Suits</b></a></li>
									<li><a href="#">-<b>&nbsp;Coats</b></a></li>
									<li><a href="#">-<b>&nbsp;Sweaters</b></a></li>
									<li><a href="#"><u><b>InnerWear</b></u></a></li>
									<li><a href="#">-<b>&nbsp;Brief</b></a></li>
									<li><a href="#">-<b>&nbsp;Vest</b></a></li>
                </ul>
							</div>
						</div>

						<div class="clearfix visible-xs"></div>

						
					</div>
					
				</div>
				
			</div>
			
                

		
			
		
		</footer>
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/slick.min.js"></script>
		<script src="js/nouislider.min.js"></script>
		<script src="js/jquery.zoom.min.js"></script>
		<script src="js/main.js"></script>
		<script src="js/actions.js"></script>
		<script src="js/sweetalert.min"></script>
		<script src="js/jquery.payform.min.js" charset="utf-8"></script>
    <script src="js/script.js"></script>
		<script>var c = 0;
        function menu(){
          if(c % 2 == 0) {
            document.querySelector('.cont_drobpdown_menu').className = "cont_drobpdown_menu active";    
            document.querySelector('.cont_icon_trg').className = "cont_icon_trg active";    
            c++; 
              }else{
            document.querySelector('.cont_drobpdown_menu').className = "cont_drobpdown_menu disable";        
            document.querySelector('.cont_icon_trg').className = "cont_icon_trg disable";        
            c++;
              }
        }
           
		
</script>
    <script type="text/javascript">
		$('.block2-btn-addcart').each(function(){
			var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
			$(this).on('click', function(){
				swal(nameProduct, "is added to cart !", "success");
			});
		});

		$('.block2-btn-addwishlist').each(function(){
			var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
			$(this).on('click', function(){
				swal(nameProduct, "is added to wishlist !", "success");
			});
		});
	</script>
	
